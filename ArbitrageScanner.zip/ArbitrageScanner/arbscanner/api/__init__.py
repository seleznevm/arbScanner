"""FastAPI application package."""

