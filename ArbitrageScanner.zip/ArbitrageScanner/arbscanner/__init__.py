"""Arbitrage scanner MVP package."""

